# tpcompu_prueba
