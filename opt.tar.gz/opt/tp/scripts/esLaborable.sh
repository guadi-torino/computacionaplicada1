#!/bin/bash

esLaborable() {
  local fecha=$1
  local diaSemana=$(date -d "$fecha" +%u)
  local diaMes=$(date -d "$fecha" +%d)
  local mes=$(date -d "$fecha" +%m)
  local feriadosArchivo="feriados"
  esFinDeSemana=false
  esFeriado=false

  # Comprobar si es fin de semana (sábado o domingo)
  if [ $diaSemana -eq 6 ] || [ $diaSemana -eq 7 ]; then
    echo "La fecha $fecha es un fin de semana."
    esFinDeSemana=true
  fi

  # Comprobar si es un feriado inamovible
  if grep -q "$mes-$diaMes" "$feriadosArchivo"; then
    motivo=$(grep "$mes-$diaMes" "$feriadosArchivo" | cut -d ':' -f 2)
    echo "La fecha $fecha es un feriado: $motivo"
    esFeriado=true
  # Calcular feriados móviles
  elif [ "$mes" -eq 8 ]; then
    if [ "$diaSemana" -eq 1 ] && [ $((($diaMes - 1) / 7 + 1)) -eq 3 ]; then
      motivo=$(grep "08-17" "$feriadosArchivo" | cut -d ':' -f 2)
      echo "La fecha $fecha es el feriado móvil del 17 de agosto: $motivo."
      esFeriado=true
    fi
  elif [ "$mes" -eq 10 ]; then
    if [ "$diaSemana" -eq 1 ] && [ $((($diaMes - 1) / 7 + 1)) -eq 2 ]; then
      motivo=$(grep "10-12" "$feriadosArchivo" | cut -d ':' -f 2)
      echo "La fecha $fecha es el feriado móvil del 12 de octubre: $motivo."
      esFeriado=true
    fi
  elif [ "$mes" -eq 11 ]; then
    if [ "$diaSemana" -eq 1 ] && [ $((($diaMes - 1) / 7 + 1)) -eq 4 ]; then
      motivo=$(grep "11-20" "$feriadosArchivo" | cut -d ':' -f 2)
      echo "La fecha $fecha es el feriado móvil del 20 de noviembre: $motivo."
      esFeriado=true
    fi
  fi
  
  if [ "$esFinDeSemana" = true ] || [ "$esFeriado" = true ]; then
    echo "No es un día laborable."
    return 0
  else
    echo "La fecha $fecha es un día laborable."
    return 1
  fi
}

