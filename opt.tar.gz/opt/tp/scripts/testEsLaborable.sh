#!/bin/bash

#Inlcuye el archivo en la función
source esLaborable.sh

#Argumento que se le pasa a la función
fecha=$1

#Verificando que le fecha se pase con el formato indicado
while [ -z "$fecha" ] || ! [[ "$fecha" =~ ^[0-9]{4}-[0-1]{1}[0-9]{1}-[0-3]{1}[0-9]{1}$ ]]; do
  echo "Por favor, proporciona una fecha en el formato 'YYYY-MM-DD' como argumento."
  read -p "Fecha (YYYY-MM-DD): " fecha
done
#Llamando a la función pasando el argumento fecha
esLaborable "$fecha"

