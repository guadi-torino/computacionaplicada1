#!/bin/bash

# Comprobar si el proceso dado como argumento está en ejecución
if pgrep -x "$1" >/dev/null; then
    echo "El proceso $1 está en ejecución."
else
    # Enviar un correo al usuario root
    echo "El proceso $1 no se está ejecutando. Enviando correo a root..."
    echo "El proceso $1 no se está ejecutando actualmente." | mail -s "Alerta el proceso $1  no se esta ejecutando" root
fi

