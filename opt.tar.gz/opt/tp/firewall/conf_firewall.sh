#!/bin/bash
# Establecer política por defecto como descartar
iptables -P INPUT DROP

# Permitir tráfico de loopback
iptables -A INPUT -i lo -j ACCEPT

# Permitir tráfico entrante de SSH
iptables -A INPUT -p tcp --dport 22 -j DROP

# Permitir tráfico entrante de WEB (puerto 80)
iptables -A INPUT -p tcp --dport 80 -j ACCEPT

# Guardar las reglas en el archivo firewall.conf
iptables-save > /opt/tp/firewall/firewall.conf

